export default function log(arg){
    console.log("logging:",arg)
}
