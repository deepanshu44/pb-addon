# bookmark inside webpage

* This add-on helps you in bookmarking inside a webpage in firefox browser so you can conveniently go back and forth in a page.
* Turn off by clicking on icon in the toolbar
* Use Ctrl+click to mark


![Screenshot of the Firefox Addon](./image.png?raw=true)

## todo
* persisting entries using storage api
* UI improvement
* ablity to delete entries(stylesheet bug first needed to be resolved)
* add smooth scroll
* dark/light mode
* zooming

## icon 
[icon](https://maps.google.com/mapfiles/kml/pushpin/ylw-pushpin.png "an icon")

